ftpsource Media Resource Driver
--------------------------------------------------------------------

Author: Michael Engel <http://www.engelwebdesign.de>
Copyright 2014

Official Documentation: no documentation until now

Bugs and Feature Requests: https://github.com/m-engel/modx-ftpsource

Questions: http://forums.modx.com


