<?php
/**
 * @package modx
 * @subpackage sources.mysql
 */
require_once (dirname(dirname(__FILE__)) . '/ftpsourcemediasource.class.php');
/**
 * @package modx
 * @subpackage sources.mysql
 */
class ftpSourceMediaSource_mysql extends ftpSourceMediaSource {
}