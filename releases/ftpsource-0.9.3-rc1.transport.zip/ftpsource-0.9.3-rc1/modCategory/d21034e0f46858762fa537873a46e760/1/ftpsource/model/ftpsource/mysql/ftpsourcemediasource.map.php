<?php
$xpdo_meta_map['ftpSourceMediaSource']= array (
  'package' => 'ftpsource',
  'version' => '1.0',
  'extends' => 'modMediaSource',
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);